import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: { extend: {
    colors: { ink: "#202827", teal: "#124B4D", mint: "#1B8A7D", paper: "#F5F2EA", sand: "#E9E3D7" },
    fontFamily: { sans: ["Arial", "Helvetica", "sans-serif"], serif: ["Georgia", "serif"] }
  }},
  plugins: []
};
export default config;