# ReScribe — by Mate-IQ

A responsive animated storefront starter for the ReScribe A5 reusable notebook. Built with Next.js, TypeScript, Three.js / React Three Fiber, Drei, Framer Motion, Tailwind CSS and Lucide icons.

## Included
- Interactive 3D notebook hero with drag-to-rotate controls
- Motion-based entrances, hover interactions and scroll reveals
- Responsive layout and mobile navigation
- Product details for A5, 30 pages, pen + cleaning cloth
- Order form with quantity control and customer delivery details
- WhatsApp order handoff when configured
- Fallback: downloads order details as a text file if WhatsApp isn't configured
- SEO metadata and Open Graph basics

## Run locally
Use Node.js 20.9+ (Node 22 recommended).

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

## Enable WhatsApp orders
Edit `.env.local` and set `NEXT_PUBLIC_WHATSAPP_NUMBER` to the business WhatsApp number in international digits-only format, e.g. `8801XXXXXXXXX`. Do not include `+`, spaces, or dashes. Restart the dev server after changing it.

Without this value, the form creates a text file of the order details instead of sending data anywhere.

## Before publishing
1. Set the real WhatsApp order number.
2. Add the actual selling price and delivery charges (currently the page intentionally asks you to confirm price with the seller).
3. Replace the illustrative 3D monogram / product rendering with approved production artwork or a real product model if available.
4. Verify all product specifications, care instructions, compatibility and included items with the supplier.
5. Set the real production domain in `src/app/layout.tsx` metadata.
6. Deploy to Vercel or another host that supports Next.js.
7. For reliable order storage, admin dashboard, inventory, automated confirmations or online payment, connect a backend/database and payment provider. This starter does not store orders on a server or process payments.

## Notes
The 3D notebook is a procedural model made from Three.js geometry, not a photorealistic scan of the final manufactured product. Update the model dimensions, cover artwork, and page/spiral details to match the physical product before using it as a precise product representation.
