 "use client";

import dynamic from "next/dynamic";
import { motion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, ArrowRight, ArrowUpRight, Check, Leaf, Menu, Recycle, Sparkles, X } from "lucide-react";
import { useRef, useState } from "react";
import OrderForm from "@/components/OrderForm";

const Notebook3D = dynamic(() => import("@/components/Notebook3D"), { ssr: false, loading: () => <div className="grid h-full min-h-[350px] place-items-center text-xs text-[#777b73]">Preparing your notebook…</div> });

const reveal = { hidden: { opacity: 0, y: 24 }, show: { opacity: 1, y: 0, transition: { duration: 0.65, ease: [0.22, 1, 0.36, 1] as const } } };

export default function Home() {
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 90]);
  const [menuOpen, setMenuOpen] = useState(false);

  return <main>
    <div className="border-b border-black/10 bg-[#124b4d] py-2 text-center text-[10px] tracking-[.13em] text-[#f5f2ea] sm:text-[11px]">A BETTER WAY TO KEEP YOUR IDEAS MOVING <span className="mx-2 text-[#81c7b5]">✳</span> REUSABLE BY DESIGN</div>
    <header className="sticky top-0 z-40 border-b border-black/[.06] bg-[#f5f2ea]/90 backdrop-blur-xl">
      <div className="container flex h-[72px] items-center justify-between">
        <a href="#home" className="flex items-center gap-3" aria-label="ReScribe home">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl border border-teal/20 text-teal"><span className="display text-xl">R<span className="text-mint">S</span></span></div>
          <div><div className="text-[16px] font-bold tracking-[.08em]">ReScribe</div><div className="mt-[-2px] text-[9px] tracking-[.14em] text-[#777b73]">BY MATE-IQ</div></div>
        </a>
        <nav className="hidden items-center gap-8 md:flex"><a className="nav-link" href="#story">Our idea</a><a className="nav-link" href="#details">The notebook</a><a className="nav-link" href="#how">How it works</a></nav>
        <a href="#order" className="hidden rounded-full bg-teal px-5 py-3 text-[11px] font-semibold text-white transition hover:bg-[#0d3c3e] sm:inline-flex">Order yours <ArrowUpRight size={14} className="ml-2"/></a>
        <button className="inline-flex h-10 w-10 items-center justify-center rounded-full border border-black/10 md:hidden" aria-label="Toggle menu" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X size={18}/> : <Menu size={18}/>}</button>
      </div>
      {menuOpen && <div className="container grid gap-4 border-t border-black/10 py-5 md:hidden"><a onClick={() => setMenuOpen(false)} href="#story" className="nav-link">Our idea</a><a onClick={() => setMenuOpen(false)} href="#details" className="nav-link">The notebook</a><a onClick={() => setMenuOpen(false)} href="#how" className="nav-link">How it works</a><a onClick={() => setMenuOpen(false)} href="#order" className="nav-link font-bold text-teal">Order yours →</a></div>}
    </header>

    <section id="home" ref={heroRef} className="container relative grid min-h-[690px] items-center gap-8 py-12 lg:grid-cols-[.94fr_1.06fr] lg:py-16">
      <motion.div initial="hidden" animate="show" variants={{ show: { transition: { staggerChildren: .12 } } }} className="relative z-10 py-4">
        <motion.div variants={reveal} className="mb-6 flex items-center gap-2"><span className="h-px w-8 bg-mint"/><span className="eyebrow text-teal">Meet your new everyday notebook</span></motion.div>
        <motion.h1 variants={reveal} className="display max-w-[650px] text-[clamp(3.5rem,7vw,6.6rem)] leading-[.96]">Good ideas<br/>deserve a <span className="italic text-teal">second</span><br/>life.</motion.h1>
        <motion.p variants={reveal} className="mt-7 max-w-[420px] text-[14px] leading-7 text-[#656b64]">Meet ReScribe: a reusable notebook for the notes, plans and little sparks you don’t want to waste paper on.</motion.p>
        <motion.div variants={reveal} className="mt-8 flex flex-wrap items-center gap-3"><a href="#order" className="button-primary">Get your ReScribe <ArrowRight size={16}/></a><a href="#details" className="button-secondary">Explore the notebook</a></motion.div>
        <motion.div variants={reveal} className="mt-10 flex items-center gap-4 text-[11px] text-[#777b73]"><div className="flex -space-x-2">{["#124b4d","#78a89a","#d5b88a"].map(c=><span key={c} style={{background:c}} className="h-7 w-7 rounded-full border-2 border-[#f5f2ea]"/>)}</div><span>One notebook. More room for ideas.</span></motion.div>
      </motion.div>
      <motion.div style={{ y: heroY }} className="relative mx-auto h-[440px] w-full max-w-[600px] sm:h-[560px]">
        <div className="hero-orb grid-paper absolute inset-[5%_2%_4%_2%] rounded-[48%_48%_42%_42%] border border-white/70"/>
        <div className="absolute left-[5%] top-[13%] z-10 rounded-full border border-black/10 bg-[#fbfaf6]/90 px-4 py-3 shadow-sm backdrop-blur"><p className="eyebrow text-teal">Made to reuse</p><p className="mt-1 text-[11px] text-[#777b73]">Less waste, more ideas.</p></div>
        <div className="absolute right-[3%] top-[22%] z-10 flex h-[76px] w-[76px] rotate-6 flex-col items-center justify-center rounded-full bg-[#d6e6db] text-teal shadow-sm"><Recycle size={20}/><span className="mt-1 text-[8px] font-bold tracking-wider">REUSE</span></div>
        <div className="absolute inset-0"><Notebook3D/></div>
        <div className="absolute bottom-[7%] left-[8%] z-10 rounded-2xl border border-white/80 bg-[#fbfaf6]/85 px-4 py-3 shadow-sm backdrop-blur"><p className="text-[10px] text-[#777b73]">Your everyday companion</p><p className="mt-1 text-sm font-semibold">Write. Erase. Repeat.</p></div>
      </motion.div>
      <a href="#story" className="absolute bottom-5 left-1/2 hidden -translate-x-1/2 items-center gap-2 text-[9px] tracking-[.18em] text-[#777b73] lg:flex">SCROLL TO DISCOVER <ArrowDown size={12}/></a>
    </section>

    <section id="story" className="border-y border-black/[.07] bg-[#eae6dc] py-20 sm:py-28">
      <div className="container grid items-start gap-10 md:grid-cols-[.7fr_1.3fr]">
        <motion.div initial="hidden" whileInView="show" viewport={{ once: true }} variants={reveal}><p className="eyebrow text-teal">A little less disposable</p><h2 className="display mt-5 text-4xl leading-tight sm:text-5xl">For thoughts that<br/><span className="italic text-teal">keep coming.</span></h2></motion.div>
        <motion.div initial="hidden" whileInView="show" viewport={{ once: true }} variants={reveal} className="max-w-2xl md:pt-2"><p className="text-[15px] leading-8 text-[#60665f]">Class notes. To-do lists. A sudden idea on the bus. ReScribe gives all those thoughts a place to land — then lets you clear the page and begin again.</p><div className="mt-8 grid gap-5 sm:grid-cols-3">{[{n:"01",t:"Capture",d:"Get the thought out of your head and onto the page."},{n:"02",t:"Keep moving",d:"Use your notebook for the next idea, not the bin."},{n:"03",t:"Start again",d:"Wipe the page when you’re ready for a fresh start."}].map(x=><div key={x.n} className="border-t border-black/15 pt-4"><span className="text-[10px] text-teal">{x.n}</span><h3 className="mt-3 text-sm font-semibold">{x.t}</h3><p className="mt-2 text-xs leading-6 text-[#777b73]">{x.d}</p></div>)}</div></motion.div>
      </div>
    </section>

    <section id="details" className="container py-20 sm:py-28">
      <div className="mb-12 flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="eyebrow text-teal">Meet the details</p><h2 className="display mt-4 text-4xl sm:text-5xl">Small details.<br/><span className="italic text-teal">Big potential.</span></h2></div><p className="max-w-[330px] text-sm leading-7 text-[#777b73]">Made for student life, planning sessions, daily lists and all the ideas still waiting to happen.</p></div>
      <div className="grid gap-4 md:grid-cols-3">
        <motion.article whileHover={{ y: -5 }} className="rounded-[24px] bg-[#eae6dc] p-6 sm:p-7"><div className="mb-9 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#d6e6db] text-teal"><Sparkles size={21}/></div><p className="eyebrow text-teal">01 / The format</p><h3 className="display mt-3 text-3xl">A5, ready to go.</h3><p className="mt-3 text-xs leading-6 text-[#777b73]">A handy size for backpacks, study desks and everyday carry.</p><div className="mt-7 border-t border-black/10 pt-4 text-xs font-semibold">A5 notebook format</div></motion.article>
        <motion.article whileHover={{ y: -5 }} className="rounded-[24px] bg-[#124b4d] p-6 text-[#f5f2ea] sm:p-7"><div className="mb-9 flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-[#a5d7c7]"><Recycle size={21}/></div><p className="eyebrow text-[#a5d7c7]">02 / The pages</p><h3 className="display mt-3 text-3xl">30 pages.<br/>New beginnings.</h3><p className="mt-3 text-xs leading-6 text-white/65">A reusable page setup for notes you can clear and write again, following the product’s care instructions.</p><div className="mt-7 border-t border-white/15 pt-4 text-xs font-semibold">Reusable notebook · 30 pages</div></motion.article>
        <motion.article whileHover={{ y: -5 }} className="rounded-[24px] bg-[#f0e5d5] p-6 sm:p-7"><div className="mb-9 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#e3d2bc] text-[#805b34]"><Leaf size={21}/></div><p className="eyebrow text-[#805b34]">03 / The essentials</p><h3 className="display mt-3 text-3xl">The little things<br/>included.</h3><p className="mt-3 text-xs leading-6 text-[#74685a]">Your planned starter set includes a compatible pen and a cleaning cloth.</p><div className="mt-7 border-t border-black/10 pt-4 text-xs font-semibold">Notebook + pen + cloth</div></motion.article>
      </div>
      <div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-black/10 p-5"><div className="flex items-center gap-3"><Check size={17} className="text-teal"/><p className="text-xs text-[#60665f]">Thoughtful, minimal, made for everyday use.</p></div><a href="#order" className="text-xs font-bold text-teal">Order ReScribe <ArrowRight className="ml-1 inline" size={13}/></a></div>
    </section>

    <section id="how" className="bg-[#eae6dc] py-20 sm:py-24">
      <div className="container"><div className="mx-auto max-w-xl text-center"><p className="eyebrow text-teal">Your new ritual</p><h2 className="display mt-4 text-4xl sm:text-5xl">Three steps.<br/><span className="italic text-teal">Infinite drafts.</span></h2></div>
        <div className="mt-12 grid gap-4 md:grid-cols-3">{[{n:"01",title:"Write it down",desc:"Use the compatible pen to capture notes, plans and ideas."},{n:"02",title:"Make it yours",desc:"Keep what matters. Build a daily habit around your notebook."},{n:"03",title:"Wipe & repeat",desc:"Follow the notebook’s care instructions to clear pages for reuse."}].map((item,i)=><motion.div key={item.n} initial={{ opacity:0,y:20 }} whileInView={{ opacity:1,y:0 }} viewport={{ once:true }} transition={{ delay:i*.12 }} className="rounded-[22px] border border-black/10 bg-[#f5f2ea]/70 p-6 sm:p-8"><div className="flex items-center justify-between"><span className="display text-4xl text-teal/45">{item.n}</span><span className="h-px w-14 bg-teal/30"/></div><h3 className="mt-8 text-base font-semibold">{item.title}</h3><p className="mt-3 text-xs leading-6 text-[#777b73]">{item.desc}</p></motion.div>)}</div>
      </div>
    </section>

    <section id="order" className="container grid gap-10 py-20 sm:py-28 lg:grid-cols-[.85fr_1.15fr]">
      <div className="lg:sticky lg:top-32 lg:self-start"><p className="eyebrow text-teal">Your next page starts here</p><h2 className="display mt-5 text-5xl leading-[1.05] sm:text-6xl">Make space<br/>for <span className="italic text-teal">more.</span></h2><p className="mt-6 max-w-sm text-sm leading-7 text-[#777b73]">Tell us where to send your ReScribe. We’ll get in touch to confirm stock, price, delivery fee and payment details before finalising your order.</p>
        <div className="mt-8 space-y-4">{["A5 reusable notebook","30 pages","Pen + cleaning cloth planned in the set"].map(t=><div key={t} className="flex items-center gap-3 text-xs"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-[#dce9df] text-teal"><Check size={13}/></span>{t}</div>)}</div>
        <div className="mt-9 border-t border-black/10 pt-5"><p className="text-[10px] uppercase tracking-[.15em] text-[#777b73]">Brand</p><p className="display mt-1 text-2xl">ReScribe <span className="font-sans text-sm tracking-normal text-[#777b73]">by Mate-IQ</span></p></div>
      </div>
      <OrderForm/>
    </section>

    <footer className="bg-[#124b4d] py-10 text-[#f5f2ea]">
      <div className="container"><div className="flex flex-col justify-between gap-7 border-b border-white/15 pb-8 sm:flex-row sm:items-end"><div><div className="display text-3xl">ReScribe</div><p className="mt-1 text-[10px] tracking-[.18em] text-white/60">BY MATE-IQ</p></div><p className="display max-w-sm text-2xl italic text-[#c6e0d5]">Write. Erase. Repeat.</p><a href="#home" className="text-xs text-white/75 hover:text-white">Back to top ↑</a></div><div className="flex flex-col justify-between gap-3 pt-5 text-[10px] text-white/55 sm:flex-row"><span>© {new Date().getFullYear()} ReScribe by Mate-IQ.</span><span>Designed for ideas that keep moving.</span></div></div>
    </footer>
  </main>;
}