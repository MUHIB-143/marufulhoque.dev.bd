import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ReScribe — by Mate-IQ | Write. Erase. Repeat.",
  description: "A reusable notebook for ideas that keep moving. Discover ReScribe by Mate-IQ.",
  metadataBase: new URL("https://example.com"),
  openGraph: {
    title: "ReScribe — by Mate-IQ",
    description: "Write. Erase. Repeat.",
    type: "website"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}