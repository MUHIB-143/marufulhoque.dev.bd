 "use client";

import { Canvas, useFrame } from "@react-three/fiber";
import { ContactShadows, Environment, Float, PresentationControls, RoundedBox, Text } from "@react-three/drei";
import { useRef } from "react";
import * as THREE from "three";

function Notebook() {
  const group = useRef<THREE.Group>(null);
  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y = THREE.MathUtils.damp(group.current.rotation.y, Math.sin(state.clock.elapsedTime * 0.35) * 0.13, 2, delta);
    }
  });
  return <group ref={group} rotation={[-0.1, -0.25, -0.08]}>
    {/* page block */}
    <RoundedBox args={[2.55, 3.45, 0.18]} radius={0.09} smoothness={4} position={[0.05, 0, -0.12]} castShadow receiveShadow>
      <meshStandardMaterial color="#eee9dd" roughness={0.82} />
    </RoundedBox>
    {/* cover */}
    <RoundedBox args={[2.62, 3.53, 0.16]} radius={0.1} smoothness={5} position={[0, 0, 0]} castShadow receiveShadow>
      <meshStandardMaterial color="#124b4d" roughness={0.48} metalness={0.04} />
    </RoundedBox>
    {/* spine rings */}
    {[-1.25, -0.83, -0.41, 0.01, 0.43, 0.85, 1.27].map((y) => (
      <mesh key={y} position={[-1.19, y, 0.105]} rotation={[Math.PI / 2, 0, 0]} castShadow>
        <torusGeometry args={[0.105, 0.026, 12, 28, Math.PI * 1.55]} />
        <meshStandardMaterial color="#d4d0c5" metalness={0.62} roughness={0.3} />
      </mesh>
    ))}
    {/* understated monogram */}
    <Text position={[0.08, 0.68, 0.091]} fontSize={0.76} maxWidth={1.6} color="#f5f2ea" anchorX="center" anchorY="middle">
      R<Text position={[0.37, 0, 0]} fontSize={0.76} color="#f5f2ea">S</Text>
    </Text>
    <mesh position={[0.12, 0.05, 0.091]}>
      <boxGeometry args={[1.2, 0.012, 0.006]} />
      <meshStandardMaterial color="#43a99b" />
    </mesh>
    <Text position={[0.1, -0.35, 0.095]} fontSize={0.28} letterSpacing={0.04} color="#f5f2ea" anchorX="center" anchorY="middle">
      ReScribe
    </Text>
    <Text position={[0.1, -0.65, 0.095]} fontSize={0.115} letterSpacing={0.08} color="#d2e3dc" anchorX="center" anchorY="middle">
      BY MATE-IQ
    </Text>
    <Text position={[0.1, -1.18, 0.095]} fontSize={0.075} letterSpacing={0.07} color="#d2e3dc" anchorX="center" anchorY="middle">
      WRITE • ERASE • REPEAT
    </Text>
  </group>;
}

export default function Notebook3D() {
  return <div className="h-full w-full min-h-[350px]">
    <Canvas shadows dpr={[1, 1.7]} camera={{ position: [0, 0, 7.3], fov: 35 }}>
      <ambientLight intensity={1.15} />
      <directionalLight position={[4, 5, 5]} intensity={2.4} castShadow shadow-mapSize={[1024, 1024]} />
      <Environment preset="studio" />
      <PresentationControls global snap={{ mass: 1, tension: 170 }} rotation={[0, 0, 0]} polar={[-0.2, 0.2]} azimuth={[-0.7, 0.7]} config={{ mass: 2, tension: 300 }}>
        <Float speed={1.4} rotationIntensity={0.08} floatIntensity={0.28}>
          <Notebook />
        </Float>
      </PresentationControls>
      <ContactShadows position={[0, -2.2, -0.5]} opacity={0.32} scale={7} blur={2.5} far={4} />
    </Canvas>
  </div>;
}