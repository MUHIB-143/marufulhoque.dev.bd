 "use client";

import { FormEvent, useState } from "react";
import { ArrowUpRight, CheckCircle2, MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

const WHATSAPP_NUMBER = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "";

export default function OrderForm() {
  const [quantity, setQuantity] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", district: "", address: "", note: "" });

  function update(key: keyof typeof form, value: string) {
    setForm((old) => ({ ...old, [key]: value }));
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const message = [
      "Hello ReScribe by Mate-IQ! I'd like to place an order.",
      "",
      `Product: ReScribe A5 Reusable Notebook`,
      `Quantity: ${quantity}`,
      `Customer: ${form.name}`,
      `Phone: ${form.phone}`,
      `District/City: ${form.district}`,
      `Delivery address: ${form.address}`,
      form.note ? `Note: ${form.note}` : "",
      "",
      "Please confirm availability, final price, delivery charge, and payment options."
    ].filter(Boolean).join("\\n");
    if (WHATSAPP_NUMBER && !WHATSAPP_NUMBER.includes("X")) {
      window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
      setSubmitted(true);
    } else {
      const blob = new Blob([message], { type: "text/plain;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "rescribe-order-details.txt";
      link.click();
      URL.revokeObjectURL(url);
      setSubmitted(true);
    }
  }

  return <motion.form onSubmit={handleSubmit} initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.15 }} transition={{ duration: 0.5 }} className="rounded-[26px] border border-black/10 bg-[#fbfaf6] p-5 sm:p-7">
    <div className="mb-6 flex items-start justify-between gap-3">
      <div><p className="eyebrow text-teal">Make it yours</p><h3 className="display mt-2 text-3xl">Place an order</h3><p className="mt-2 max-w-sm text-xs leading-5 text-[#777b73]">Share your details. We’ll confirm availability, price, delivery and payment with you.</p></div>
      <div className="rounded-full bg-[#e5eee8] p-3 text-teal"><MessageCircle size={20}/></div>
    </div>
    <div className="mb-5 flex items-center justify-between rounded-2xl bg-[#f1eee5] p-4">
      <div><p className="text-sm font-semibold">ReScribe A5 Notebook</p><p className="mt-1 text-[11px] text-[#777b73]">Reusable · 30 pages · pen + cloth</p></div>
      <div className="flex items-center gap-3">
        <button type="button" aria-label="Decrease quantity" onClick={() => setQuantity(Math.max(1, quantity - 1))} className="flex h-8 w-8 items-center justify-center rounded-full border border-black/10 bg-white text-lg">−</button>
        <span className="w-4 text-center text-sm font-semibold">{quantity}</span>
        <button type="button" aria-label="Increase quantity" onClick={() => setQuantity(Math.min(50, quantity + 1))} className="flex h-8 w-8 items-center justify-center rounded-full border border-black/10 bg-white text-lg">+</button>
      </div>
    </div>
    <div className="grid gap-4 sm:grid-cols-2">
      <label><span className="label">Full name *</span><input className="input-field" required autoComplete="name" value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="Your name"/></label>
      <label><span className="label">Phone number *</span><input className="input-field" required inputMode="tel" autoComplete="tel" value={form.phone} onChange={(e) => update("phone", e.target.value)} placeholder="01XXXXXXXXX"/></label>
      <label className="sm:col-span-2"><span className="label">District / City *</span><input className="input-field" required autoComplete="address-level2" value={form.district} onChange={(e) => update("district", e.target.value)} placeholder="e.g. Dhaka, Savar"/></label>
      <label className="sm:col-span-2"><span className="label">Full delivery address *</span><textarea className="input-field min-h-[88px] resize-y" required autoComplete="street-address" value={form.address} onChange={(e) => update("address", e.target.value)} placeholder="House, road, area and nearby landmark"/></label>
      <label className="sm:col-span-2"><span className="label">Anything else? (optional)</span><input className="input-field" value={form.note} onChange={(e) => update("note", e.target.value)} placeholder="Preferred delivery time, cover preference…"/></label>
    </div>
    <button type="submit" className="button-primary mt-5 w-full">{submitted ? <><CheckCircle2 size={16}/> Order details prepared</> : <>Continue to order <ArrowUpRight size={16}/></>}</button>
    <p className="mt-3 text-center text-[10px] leading-4 text-[#777b73]">No online payment is taken here. Your order is not confirmed until the seller contacts you.</p>
    {!WHATSAPP_NUMBER && <p className="mt-2 text-center text-[10px] text-[#9a6c30]">Setup needed: add your WhatsApp number in <code>.env.local</code> to enable WhatsApp order handoff.</p>}
  </motion.form>;
}